import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.UIManager;

public class GamePlay {

	static JFrame frame;
	static Posicion ORIGEN ;
	static Matriz_Logica MATRIZ_Log_Actual;
	static Matriz_Grafica MATRIZ_Graf_Actual;
	static KeyBoard TECLADO_Game;
	static Cronometro CRONOMETRO_Game;
	static int Nivel;
	static JLabel Matriz3X3;
	static JLabel Matriz4X4;
	static JLabel Matriz5X5;
	static JLabel Presentacion;
	static JLabel Stop;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
					GamePlay window = new GamePlay();
					window.frame.setVisible(true);					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GamePlay() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.setBounds(150, 150, 400, 400);
		Image icon = new ImageIcon(getClass().getResource("/Imagenes/Icono.png")).getImage();
	    frame.setIconImage(icon);
		frame.getContentPane().setBackground(Color.ORANGE);
		frame.setTitle("2D-Cube");
		frame.setResizable(false); 

		Nivel=1;
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		Presentacion = new JLabel();
		ImageIcon Present = new ImageIcon(this.getClass().getResource("/Imagenes/Presentacion.png"));
		Presentacion.setBounds(22,97,350,215);
		Presentacion.setIcon(Present);
		frame.getContentPane().add(Presentacion);
		
		Stop = new JLabel();
		ImageIcon StopTime = new ImageIcon(this.getClass().getResource("/Imagenes/Stop.png"));
		Stop.setBounds(9,307,376,65);
		Stop.setIcon(StopTime);
		
		Matriz3X3 = new JLabel();
		ImageIcon Matriz_Nivel_1= new ImageIcon(this.getClass().getResource("/Imagenes/Matriz 3X3.png"));
		Matriz3X3.setBounds(118,126,158,158);
		Matriz3X3.setIcon(Matriz_Nivel_1);	
	
		Matriz4X4 = new JLabel();
		ImageIcon Matriz_Nivel_2 = new ImageIcon(this.getClass().getResource("/Imagenes/Matriz 4X4.png"));
		Matriz4X4.setBounds(93,101,208,208);
		Matriz4X4.setIcon(Matriz_Nivel_2);
	
		
		Matriz5X5 = new JLabel();
		ImageIcon Matriz_Nivel_3 = new ImageIcon(this.getClass().getResource("/Imagenes/Matriz 5X5.png"));
		Matriz5X5.setBounds(68,76,258,258);
		Matriz5X5.setIcon(Matriz_Nivel_3);
		
		JLabel NombreGame = new JLabel();
		ImageIcon Titulo = new ImageIcon(this.getClass().getResource("/Imagenes/Titulo.png"));
		NombreGame.setBounds(60,22,300,50);
		NombreGame.setIcon(Titulo);
		frame.getContentPane().add(NombreGame);
		
		KeyBoard Teclado = new KeyBoard();
		TECLADO_Game = Teclado;
		frame.getContentPane().add(Teclado);
		
		ORIGEN = new Posicion();
		
		CRONOMETRO_Game = new Cronometro(frame);
	}
	
	public static void ArrancarJuego(){
		frame.getContentPane().remove(Presentacion);
		
		CRONOMETRO_Game.Activar();
		CRONOMETRO_Game.start();
		TECLADO_Game.HabilitarCursor();

		ORIGEN.SetPosicionX(0);
		ORIGEN.SetPosicionY(0);
		
		MATRIZ_Log_Actual = new Matriz_Logica (3);
		MATRIZ_Log_Actual.LLenarValores();
		MATRIZ_Log_Actual.MezclarValores(ORIGEN);
		
		MATRIZ_Graf_Actual = new Matriz_Grafica (3);
		MATRIZ_Graf_Actual.SetearIconos(MATRIZ_Log_Actual);
		MATRIZ_Graf_Actual.MostrarIconos(frame);
		
		frame.getContentPane().add(Matriz3X3);
		
		frame.repaint();
	    frame.validate();
	}
	
	public static Posicion PedirPosicion(){
		return ORIGEN;
	}
	
	public static Matriz_Logica PedirMatriz(){
		return MATRIZ_Log_Actual;
	}
	
	public static void SetPantalla(){
		MATRIZ_Graf_Actual.EliminarIconos(frame);
		MATRIZ_Graf_Actual.SetearIconos(MATRIZ_Log_Actual);
		MATRIZ_Graf_Actual.MostrarIconos(frame);
	}
	
	public static void EvaluarFinJuego(){
		if(MATRIZ_Log_Actual.MatrizOrdenada()){
			Nivel++;
			switch (Nivel) {
		      case 2:
		  		  MATRIZ_Graf_Actual.EliminarIconos(frame);

		  		  ORIGEN.SetPosicionX(0);
		  		  ORIGEN.SetPosicionY(0);
		  		
		  		  MATRIZ_Log_Actual = new Matriz_Logica (4);
		  		  MATRIZ_Log_Actual.LLenarValores();
		  		  MATRIZ_Log_Actual.MezclarValores(ORIGEN);
		  		
		  		  MATRIZ_Graf_Actual = new Matriz_Grafica (4);
		  		  MATRIZ_Graf_Actual.SetearIconos(MATRIZ_Log_Actual);
		  		  MATRIZ_Graf_Actual.MostrarIconos(frame);
		  		  
		    	  frame.getContentPane().remove(Matriz3X3);
		    	  frame.getContentPane().add(Matriz4X4);
		  		  
		    	  frame.repaint();
			      frame.validate();
		    	  break;
		      case 3:
		  		  MATRIZ_Graf_Actual.EliminarIconos(frame);
		    	  
		    	  ORIGEN.SetPosicionX(0);
		  		  ORIGEN.SetPosicionY(0);
		  		
		  		  MATRIZ_Log_Actual = new Matriz_Logica (5);
		  		  MATRIZ_Log_Actual.LLenarValores();
		  		  MATRIZ_Log_Actual.MezclarValores(ORIGEN);
		  		
		  		  MATRIZ_Graf_Actual = new Matriz_Grafica (5);
		  		  MATRIZ_Graf_Actual.SetearIconos(MATRIZ_Log_Actual);
		  		  MATRIZ_Graf_Actual.MostrarIconos(frame);
		    	  
				  frame.getContentPane().remove(Matriz4X4);
				  frame.getContentPane().add(Matriz5X5);
				  
		    	  frame.repaint();
			      frame.validate();
		          break;
		      case 4:
				  TECLADO_Game.setFocusable(false);
				  
				  CRONOMETRO_Game.Desactivar();
				  
				  frame.getContentPane().add(Stop);
			      frame.repaint();
				  frame.validate();
		          break;
		      default:
		          System.out.println("error" );
		          break;
		    }
		}
	}
	
}
