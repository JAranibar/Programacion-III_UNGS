public class Posicion {

	private int x;
	private int y;
	
	public Posicion(){
	}
	
	public int GetPosicionX(){
		return this.x;
	}
	
	public int GetPosicionY(){
		return this.y;
	}
	
	public void SetPosicionX(int x){
		this.x=x;;
	}
	
	public void SetPosicionY(int y){
		this.y=y;
	}
	
}
