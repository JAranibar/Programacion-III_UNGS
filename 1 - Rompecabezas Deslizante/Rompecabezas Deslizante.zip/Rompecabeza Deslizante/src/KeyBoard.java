import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class KeyBoard extends JPanel{

	private boolean Enable;
	
	public KeyBoard() {
		KeyListener listener = new MyKeyListener();
		addKeyListener(listener);
		setFocusable(true);
		this.Enable=false;
	}
	
	public class MyKeyListener implements KeyListener {
		
		@Override
		public void keyTyped(KeyEvent e) {
		}

		@Override
		public void keyPressed(KeyEvent e) {
			if (KeyEvent.VK_ENTER==e.getKeyCode()&&!Enable){
				GamePlay.ArrancarJuego();
			}
			if (Enable){
				if (KeyEvent.VK_DOWN==e.getKeyCode()){
					if(!FueraDeRangoDOWN(GamePlay.PedirPosicion().GetPosicionX())){
						Posicion P = GamePlay.PedirPosicion();
						int x = GamePlay.PedirPosicion().GetPosicionX()+1;
						int y = GamePlay.PedirPosicion().GetPosicionY();	
						GamePlay.PedirMatriz().ConmutarPosicion(P, x, y);
						GamePlay.SetPantalla();
						GamePlay.EvaluarFinJuego();
					}
				}
				
				if (KeyEvent.VK_UP==e.getKeyCode()){
					if(!FueraDeRangoUP(GamePlay.PedirPosicion().GetPosicionX())){
						Posicion P = GamePlay.PedirPosicion();
						int x = GamePlay.PedirPosicion().GetPosicionX()-1;
						int y = GamePlay.PedirPosicion().GetPosicionY();	
						GamePlay.PedirMatriz().ConmutarPosicion(P, x, y);
						GamePlay.SetPantalla();
						GamePlay.EvaluarFinJuego();
					}
					
				}
				if (KeyEvent.VK_LEFT==e.getKeyCode()){
					if(!FueraDeRangoLEFT(GamePlay.PedirPosicion().GetPosicionY())){
						Posicion P = GamePlay.PedirPosicion();
						int x = GamePlay.PedirPosicion().GetPosicionX();
						int y = GamePlay.PedirPosicion().GetPosicionY()-1;	
						GamePlay.PedirMatriz().ConmutarPosicion(P, x, y);
						GamePlay.SetPantalla();
						GamePlay.EvaluarFinJuego();
					}
				}
				if (KeyEvent.VK_RIGHT==e.getKeyCode()){
					if(!FueraDeRangoRIGHT(GamePlay.PedirPosicion().GetPosicionY())){
						Posicion P = GamePlay.PedirPosicion();
						int x = GamePlay.PedirPosicion().GetPosicionX();
						int y = GamePlay.PedirPosicion().GetPosicionY()+1;	
						GamePlay.PedirMatriz().ConmutarPosicion(P, x, y);
						GamePlay.SetPantalla();
						GamePlay.EvaluarFinJuego();
					}
				}		
			}
			
			
		}

		@Override
		public void keyReleased(KeyEvent e) {
		}
		
		public boolean FueraDeRangoUP(int num){
			if(num-1>=0){
				return false;
			}
			return true;
		}
		
		public boolean FueraDeRangoDOWN(int num){
			if(num+1<=GamePlay.PedirMatriz().GetTama�o()-1){
				return false;
			}
			return true;
		}
		
		public boolean FueraDeRangoLEFT(int num){
			if(num-1>=0){
				return false;
			}
			return true;
		}
		
		public boolean FueraDeRangoRIGHT(int num){
			if(num+1<=GamePlay.PedirMatriz().GetTama�o()-1){
				return false;
			}
			return true;
		}
		
	}
	
	public void HabilitarCursor(){
		this.Enable=true;
	}
	
	public void DeshabilitarCursor(){
		this.Enable=false;
	}
	
}
