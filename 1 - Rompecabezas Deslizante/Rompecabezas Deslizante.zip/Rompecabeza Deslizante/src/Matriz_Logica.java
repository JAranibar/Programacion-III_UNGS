public class Matriz_Logica {

	private int[][] Matriz_Log;

	public Matriz_Logica(int Tama�o){
        this.Matriz_Log = new int[Tama�o][Tama�o];
    }
	
	public void LLenarValores(){
        int numero=0;
        for(int i=0;i<Matriz_Log.length;i++){
			for(int j=0;j<Matriz_Log.length;j++){
				Matriz_Log[i][j]=numero;			
				numero++;
			}
		}
	}
	
	public void MezclarValores(Posicion Pos){
		int CantDeConmutaciones=1000;
		for (int i=0;i<CantDeConmutaciones;i++){	
			int Variable=((int)(Math.random()*2));
			int Operacion=((int)(Math.random()*2));
			if(Variable==0){
				if(Operacion==0){
					if(Pos.GetPosicionX()-1>=0){
						ConmutarPosicion(Pos,Pos.GetPosicionX()-1,Pos.GetPosicionY());
					}
				}else{
					if(Pos.GetPosicionX()+1<=Matriz_Log.length-1){
						ConmutarPosicion(Pos,Pos.GetPosicionX()+1,Pos.GetPosicionY());
					}
				}
			}else{
				if(Operacion==0){
					if(Pos.GetPosicionY()-1>=0){
						ConmutarPosicion(Pos,Pos.GetPosicionX(),Pos.GetPosicionY()-1);
					}
				}else{
					if(Pos.GetPosicionY()+1<=Matriz_Log.length-1){
						ConmutarPosicion(Pos,Pos.GetPosicionX(),Pos.GetPosicionY()+1);
					}
				}
			}
		}
	}	

	public int GetValor(int x,int y){
		return this.Matriz_Log[x][y];
	}
	
	public int GetTama�o(){
		return this.Matriz_Log.length;
	}
	
	public void ConmutarPosicion(Posicion Pos,int x,int y){
		this.Matriz_Log[Pos.GetPosicionX()][Pos.GetPosicionY()]=this.Matriz_Log[x][y];
		this.Matriz_Log[x][y]=0;
		Pos.SetPosicionX(x);
		Pos.SetPosicionY(y);
	}
	
	public boolean MatrizOrdenada(){
		int numero=0;
        for(int i=0;i<Matriz_Log.length;i++){
			for(int j=0;j<Matriz_Log.length;j++){
				if(Matriz_Log[i][j]!=numero){
					return false;
				}			
				numero++;
			}
        }
        return true;
	}
	
}
