import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Matriz_Grafica {

	private JLabel[][] MTZ;
	
	public Matriz_Grafica(int Tama�o) {		
		MTZ = new JLabel [Tama�o][Tama�o];
	}
	
	public void SetearIconos(Matriz_Logica MtzLog) {
		int PosicionX=PosicionarX();
		int PosicionY=PosicionarY();
		
		for(int i=0; i<MTZ.length;i++){
			for(int j=0; j<MTZ.length;j++){
				JLabel a = new JLabel();
				ImageIcon icon = null;		
				switch ( MtzLog.GetValor(i, j) ) {
			      case 0:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/0.png"));			          
			           break;
			      case 1:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/1.png"));			          
			           break;
			      case 2:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/2.png"));
			           break;
			      case 3:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/3.png"));
			           break;
			      case 4:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/4.png"));			           
			           break;
			      case 5:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/5.png"));			          
			           break;
			      case 6:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/6.png"));
			           break;
			      case 7:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/7.png"));
			           break;
			      case 8:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/8.png"));			          
			           break;
			      case 9:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/9.png"));			          
			           break;
			      case 10:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/10.png"));
			           break;
			      case 11:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/11.png"));
			           break;
			      case 12:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/12.png"));			           
			           break;
			      case 13:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/13.png"));			          
			           break;
			      case 14:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/14.png"));
			           break;
			      case 15:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/15.png"));
			           break;
			      case 16:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/16.png"));			          
			           break;
			      case 17:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/17.png"));			          
			           break;
			      case 18:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/18.png"));
			           break;
			      case 19:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/19.png"));
			           break;
			      case 20:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/20.png"));			           
			           break;
			      case 21:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/21.png"));			          
			           break;
			      case 22:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/22.png"));
			           break;
			      case 23:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/23.png"));
			           break;
			      case 24:
			    	   icon = new ImageIcon(this.getClass().getResource("/Imagenes/24.png"));			          
			           break;
			      default:
			           System.out.println("error" );
			           break;
			      }
				
				a.setBounds(PosicionX,PosicionY,40,40);
				a.setIcon(icon);
				MTZ[i][j] = a;
				PosicionX=PosicionX+50;
			}
			PosicionX=PosicionarX();
			PosicionY=PosicionY+50;	
		}
	}
	
	public void MostrarIconos(JFrame Ventana){
		for(int i=0; i<MTZ.length;i++){
			for(int j=0; j<MTZ.length;j++){
				JLabel Imagen = this.MTZ[i][j];
		        Ventana.getContentPane().add(Imagen);
			}
		}

	    Ventana.repaint();
	    Ventana.validate();
	}

	public void EliminarIconos(JFrame Ventana){
		for(int i=0; i<MTZ.length;i++){
			for(int j=0; j<MTZ.length;j++){
				Ventana.getContentPane().remove(MTZ[i][j]);	
			}
		}
	}

	public int PosicionarX(){
		switch (GamePlay.Nivel) {
		case 1:
			return 127;
		case 2:
			return 102;
		case 3:
			return 77;
		default:
	        System.out.println("error" );
	        break;
	    }
		return 0;
	}
	
	public int PosicionarY(){
		switch (GamePlay.Nivel) {
		case 1:
			return 135;
		case 2:
			return 110;
		case 3:
			return 85;
		default:
	        System.out.println("error" );
	        break;
	    }
		return 0;
	}
	
}