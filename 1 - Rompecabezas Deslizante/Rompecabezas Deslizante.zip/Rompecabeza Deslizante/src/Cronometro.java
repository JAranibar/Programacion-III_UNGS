import java.awt.Color;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Cronometro extends Thread {

    JLabel tiempo;
    boolean cronometroActivo;
    JFrame frame;
	
    public Cronometro(JFrame frame){
        super();
        cronometroActivo=false;
        tiempo = new JLabel();
        tiempo.setBounds(157, 343, 80, 25);
        tiempo.setText( "00" + ":" + "00" );
        tiempo.setFont( new Font( Font.DIALOG_INPUT, Font.CENTER_BASELINE, 25 ) );
        tiempo.setHorizontalAlignment( JLabel.CENTER );
        tiempo.setForeground( Color.green );
        tiempo.setBackground( Color.BLACK );
        tiempo.setOpaque( true );
        frame.getContentPane().add(tiempo); 
    }   
    
    public void run() {
	    int nuMin=0;
	    int nuSeg=0; 
	    String min="", seg="";
	    try {
		    while(cronometroActivo){         
		       if(nuSeg!=59) {
		           nuSeg++;                                  
		        }else{             
		        	nuSeg=0;
		            nuMin++;
		        }
		       if( nuMin < 10 ) min = "0" + nuMin;
		       else min = String.valueOf(nuMin);
		       if( nuSeg < 10 ) seg = "0" + nuSeg;
		       else seg = String.valueOf(nuSeg);
		
		    tiempo.setText( min + ":" + seg );
		    sleep(1000);
		    }           
	    }catch (Exception ex) {
	        System.out.println(ex.getMessage());
	    }                 
    }
  
    public void Activar(){
    	cronometroActivo=true;
    }
    
    public void Desactivar(){
    	cronometroActivo=false;
    }
    
 }