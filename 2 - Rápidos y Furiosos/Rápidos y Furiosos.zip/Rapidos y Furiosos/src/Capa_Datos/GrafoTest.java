package Capa_Datos;

import static org.junit.Assert.*;

import org.junit.Test;

public class GrafoTest {

	//Caso Borde.
	@Test
	public void VerticeExistenteCasoBordeTest() {
		Grafo grafo = new Grafo();
		grafo.AgregarVertice();
		grafo.AgregarVertice();
		grafo.AgregarVertice();
		assertTrue( grafo.CheckearExistenciaVertice(0) && grafo.CheckearExistenciaVertice(2));
	}
	
	@Test
	public void VerticeExistenteTest() {
		Grafo grafo = new Grafo();
		grafo.AgregarVertice();
		grafo.AgregarVertice();
		grafo.AgregarVertice();
		assertTrue( grafo.CheckearExistenciaVertice(1) );
	}
	
	@Test
	public void VerticeInexistenteTest() {
		Grafo grafo = new Grafo();
		grafo.AgregarVertice();
		grafo.AgregarVertice();
		grafo.AgregarVertice();
		assertFalse( grafo.CheckearExistenciaVertice(3));
	}
	
	@Test
	public void AristasExistenteTest(){
		Grafo grafo = new Grafo();
		grafo.AgregarVertice();
		grafo.AgregarVertice();
		grafo.AgregarVertice();
		Tupla_Arista T1 = new Tupla_Arista (true,8,1);
		Tupla_Arista T2 = new Tupla_Arista (true,23,2);
		Tupla_Arista T3 = new Tupla_Arista (true,15,2);
		grafo.AgregarArista(0, T1);
		grafo.AgregarArista(0, T2);
		grafo.AgregarArista(1, T3);
		assertTrue( grafo.CheckearExistenciaArista(0, 2));
	}

	@Test
	public void AristasInexistenteTest(){
		Grafo grafo = new Grafo();
		grafo.AgregarVertice();
		grafo.AgregarVertice();
		grafo.AgregarVertice();
		Tupla_Arista T1 = new Tupla_Arista (true,8,1);
		Tupla_Arista T2 = new Tupla_Arista (true,23,2);
		grafo.AgregarArista(0, T1);
		grafo.AgregarArista(0, T2);
		assertFalse( grafo.CheckearExistenciaArista(1, 2));
	}
	
	@Test
	public void CantidadDeAristas(){
		Grafo grafo = new Grafo();
		grafo.AgregarVertice();
		grafo.AgregarVertice();
		grafo.AgregarVertice();
		grafo.AgregarVertice();
		Tupla_Arista T1 = new Tupla_Arista (true,8,1);
		Tupla_Arista T2 = new Tupla_Arista (true,23,2);
		Tupla_Arista T3 = new Tupla_Arista (true,15,3);
		grafo.AgregarArista(0, T1);
		grafo.AgregarArista(0, T2);
		grafo.AgregarArista(0, T3);
		assertEquals (3,grafo.CantidadDeVecinos(0));
	}
	

	@Test
	public void EliminarArista(){
		// Creamos un Grafo con 4 nodos.
		// y 3 aristas saliendo de 0(nodo) a los demas. 
		Grafo grafo = new Grafo();
		grafo.AgregarVertice();
		grafo.AgregarVertice();
		grafo.AgregarVertice();
		grafo.AgregarVertice();
		Tupla_Arista T1 = new Tupla_Arista (true,8,1);
		Tupla_Arista T2 = new Tupla_Arista (true,23,2);
		Tupla_Arista T3 = new Tupla_Arista (true,15,3);
		grafo.AgregarArista(0, T1);
		grafo.AgregarArista(0, T2);
		grafo.AgregarArista(0, T3);
		
		// Eliminamos 1 arista de 0, es decir 3-1=2.
		grafo.EliminarArista(0, 2);
		
		// Verificamos su correcta sustraccion.
		assertEquals (2,grafo.CantidadDeVecinos(0));
	}
	
	@Test
	public void CheckDistanciaArista(){
		Grafo grafo = new Grafo();
		grafo.AgregarVertice();
		grafo.AgregarVertice();
		grafo.AgregarVertice();
		Tupla_Arista T1 = new Tupla_Arista (true,8,1);
		Tupla_Arista T2 = new Tupla_Arista (true,23,2);
		grafo.AgregarArista(0, T1);
		grafo.AgregarArista(0, T2);
		
		assertEquals (8,grafo.DistanciaArista(0, 1));
	}
	
	@Test
	public void CheckPeajeArista(){

		Grafo grafo = new Grafo();
		grafo.AgregarVertice();
		grafo.AgregarVertice();
		grafo.AgregarVertice();
		Tupla_Arista T1 = new Tupla_Arista (true,8,1);
		Tupla_Arista T2 = new Tupla_Arista (true,23,2);
		grafo.AgregarArista(0, T1);
		grafo.AgregarArista(0, T2);
		
		assertTrue(grafo.PeajeArista(0, 1));
	}
	
}
