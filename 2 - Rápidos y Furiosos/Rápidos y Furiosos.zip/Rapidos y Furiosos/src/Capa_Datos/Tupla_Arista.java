package Capa_Datos;

public class Tupla_Arista {

	private Boolean Peaje;
	private int Distancia;
	private int Destino;
	
	public Tupla_Arista(Boolean Bool,int Dist, int Dest){
		this.Peaje=Bool;
		this.Distancia=Dist;
		this.Destino=Dest;
	}
	
	public Boolean GetPeaje(){
		return this.Peaje;
	}
	
	public int GetDistancia(){
		return this.Distancia;
	}
	
	public int GetDestino(){
		return this.Destino;
	}
	
	public void SetDestino(int dest){
		this.Destino=dest;
	}
	
}
