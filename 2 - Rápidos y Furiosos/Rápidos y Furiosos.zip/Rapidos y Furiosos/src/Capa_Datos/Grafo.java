package Capa_Datos;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class Grafo{

	private ArrayList<HashSet<Tupla_Arista>> Vecinos;

	public Grafo(){
		Vecinos = new ArrayList<HashSet<Tupla_Arista>>();
	}
	
	public void AgregarVertice(){
		Vecinos.add(new HashSet<Tupla_Arista>());
	}
	
	public void AgregarArista(int origen,Tupla_Arista Tupla){
		if(!CheckearExistenciaArista(origen,Tupla.GetDestino())){
			Vecinos.get(origen).add(Tupla);
		}else{
			throw new IllegalArgumentException("Arista ya Existente!!!");
		}
	}
	
	public int GetVertices(){
		return Vecinos.size();
	}
	
	public HashSet<Tupla_Arista> GetAristas(int Vertice){
		return Vecinos.get(Vertice);
	}
	
	public Boolean CheckearExistenciaArista(int orig, int dest){
		HashSet<Tupla_Arista> Lista_Tupla = Vecinos.get(orig);
		Iterator<Tupla_Arista> itr = Lista_Tupla.iterator();
		while(itr.hasNext()){
			int Relacion=itr.next().GetDestino();
			if(Relacion==dest){
				return true;
			}
		}
		return false;
	}

	public Boolean CheckearExistenciaVertice(int Vertice){
		if(Vertice<Vecinos.size()&&Vertice>=0){
			return true;
		}
		return false;
	}
	
	public int CantidadDeVecinos(int Vertice){
		HashSet<Tupla_Arista> Lista_Tupla = Vecinos.get(Vertice);
		return Lista_Tupla.size();
	}
	
	public void EliminarArista(int Origen, int Destino){
		if(CheckearExistenciaArista(Origen,Destino)){
			HashSet<Tupla_Arista> Lista_Tupla1 = Vecinos.get(Origen);
			Iterator<Tupla_Arista> itr1 = Lista_Tupla1.iterator();
			while(itr1.hasNext()){
				Tupla_Arista Tupla = itr1.next();
				int Dest=Tupla.GetDestino();
				if(Destino==Dest){
					itr1.remove();
				}
			}
		}else{
			throw new IllegalArgumentException("Arista No Existe!!!");
		}
	}
	
	public int DistanciaArista(int Origen, int Destino){
		if(CheckearExistenciaArista(Origen,Destino)){
			HashSet<Tupla_Arista> Lista_Tupla1 = Vecinos.get(Origen);
			Iterator<Tupla_Arista> itr1 = Lista_Tupla1.iterator();
			while(itr1.hasNext()){
				Tupla_Arista Tupla = itr1.next();
				int Dest=Tupla.GetDestino();
				if(Destino==Dest){
					return Tupla.GetDistancia();
				}
			}
		}else{
			throw new IllegalArgumentException("Arista No Existe!!!");
		}
		return 0;
	}
	
	public boolean PeajeArista(int Origen, int Destino){
		if(CheckearExistenciaArista(Origen,Destino)){
			HashSet<Tupla_Arista> Lista_Tupla1 = Vecinos.get(Origen);
			Iterator<Tupla_Arista> itr1 = Lista_Tupla1.iterator();
			while(itr1.hasNext()){
				Tupla_Arista Tupla = itr1.next();
				int Dest=Tupla.GetDestino();
				if(Destino==Dest){
					return Tupla.GetPeaje();
				}
			}
		}else{
			throw new IllegalArgumentException("Arista No Existe!!!");
		}
		return true;
	}
	
}
