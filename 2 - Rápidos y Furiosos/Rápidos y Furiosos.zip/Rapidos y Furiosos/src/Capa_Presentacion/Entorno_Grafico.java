package Capa_Presentacion;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.UIManager;

import Capa_Aplicacion.ModGraf_Dijsktra;
import Capa_Aplicacion.Etiqueta;
import Capa_Datos.Grafo;
import Capa_Datos.Tupla_Arista;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.JTextArea;

import java.awt.Font;

import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

public class Entorno_Grafico{

	private JFrame frame;
	
	private static Grafo Graf;
	
	private JTextField TextVertices;
	private JTextField TextOrigen;
	private JTextField TextDestino;
	private JTextField TextDistancia;
	private JTextField TextInicial;
	private JTextField TextFinal;
	private JTextField Max_Peajes;

	private static String Registro="";
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
					Entorno_Grafico window = new Entorno_Grafico();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Entorno_Grafico() {	
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 500, 335);
		Image icon = new ImageIcon(getClass().getResource("/Imagen/Icono.png")).getImage();
	    frame.setIconImage(icon);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setBackground(Color.ORANGE);
		frame.setTitle("Rapidos y Furiosos");
		frame.setResizable(false); 
		frame.getContentPane().setLayout(null);
		
		Graf = new Grafo();
		
		ModGraf_Dijsktra Metodo = new ModGraf_Dijsktra();

		TextOrigen = new JTextField();
		TextOrigen.setBounds(66, 212, 18, 20);
		TextOrigen.setHorizontalAlignment(SwingConstants.CENTER);
		TextOrigen.setFont(new Font("Tahoma", Font.PLAIN, 11));
		TextOrigen.setColumns(10);
		frame.getContentPane().add(TextOrigen);
		
		TextDestino = new JTextField();
		TextDestino.setBounds(66, 240, 18, 20);
		TextDestino.setHorizontalAlignment(SwingConstants.CENTER);
		TextDestino.setColumns(10);
		frame.getContentPane().add(TextDestino);
		
		TextDistancia = new JTextField();
		TextDistancia.setBounds(143, 240, 26, 20);
		TextDistancia.setHorizontalAlignment(SwingConstants.CENTER);
		TextDistancia.setColumns(10);
		frame.getContentPane().add(TextDistancia);
		
		TextInicial = new JTextField();
		TextInicial.setBounds(66, 267, 18, 20);
		TextInicial.setHorizontalAlignment(SwingConstants.CENTER);
		TextInicial.setColumns(10);
		frame.getContentPane().add(TextInicial);
		
		TextFinal = new JTextField();
		TextFinal.setBounds(129, 267, 18, 20);
		TextFinal.setHorizontalAlignment(SwingConstants.CENTER);
		TextFinal.setColumns(10);
		frame.getContentPane().add(TextFinal);
		
		Max_Peajes = new JTextField();
		Max_Peajes.setBounds(209, 267, 18, 20);
		Max_Peajes.setHorizontalAlignment(SwingConstants.CENTER);
		Max_Peajes.setColumns(10);
		frame.getContentPane().add(Max_Peajes);
		
		JRadioButton BottonPeaje = new JRadioButton("Peaje");
		BottonPeaje.setBounds(95, 211, 55, 23);
		frame.getContentPane().add(BottonPeaje);
		
		JLabel lblOrigen = new JLabel("Origen:");
		lblOrigen.setBounds(20, 215, 46, 14);
		frame.getContentPane().add(lblOrigen);
		
		JLabel lblDestino = new JLabel("Destino:");
		lblDestino.setBounds(20, 243, 46, 14);
		frame.getContentPane().add(lblDestino);
		
		JLabel lblDistancia = new JLabel("Distancia:");
		lblDistancia.setBounds(95, 243, 50, 14);
		frame.getContentPane().add(lblDistancia);
				
		JLabel lblS = new JLabel("Inicio (s):");
		lblS.setBounds(20, 269, 46, 14);
		frame.getContentPane().add(lblS);
		
		JLabel lblT = new JLabel("Fin (t):");
		lblT.setBounds(95, 269, 34, 14);
		frame.getContentPane().add(lblT);
		
		JLabel lblMaxVisados = new JLabel("Peaje Max:");
		lblMaxVisados.setBounds(154, 269, 60, 14);
		frame.getContentPane().add(lblMaxVisados);

		JLabel lblNotificaciones = new JLabel("Notificaciones:");
		lblNotificaciones.setBounds(325, 195, 154, 14);
		lblNotificaciones.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNotificaciones.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(lblNotificaciones);

		JLabel lblRegistroDeAristas = new JLabel("Registro de Aristas:");
		lblRegistroDeAristas.setBounds(20, 8, 109, 14);
		frame.getContentPane().add(lblRegistroDeAristas);

		JLabel lblVertices = new JLabel("Vertices:");
		lblVertices.setBounds(165, 215, 46, 14);
		frame.getContentPane().add(lblVertices);
		
		JButton BottonAddVert = new JButton("Agr. Ver.");
		BottonAddVert.setBounds(237, 211, 78, 23);
		frame.getContentPane().add(BottonAddVert);
		
		JButton ButtonAddArista = new JButton("Agr. Ari.");
		ButtonAddArista.setBounds(237, 238, 78, 23);
		frame.getContentPane().add(ButtonAddArista);
		
		JButton BottonAppAlg = new JButton("App. Alg.");
		BottonAppAlg.setBounds(237, 265, 78, 23);
		frame.getContentPane().add(BottonAppAlg);

		TextVertices = new JTextField();
		TextVertices.setBounds(209, 212, 18, 20);
		TextVertices.setHorizontalAlignment(SwingConstants.CENTER);
		TextVertices.setEnabled(false);
		frame.getContentPane().add(TextVertices);
		TextVertices.setColumns(10);
		TextVertices.setText("0");

		JTextArea Notificaciones = new JTextArea();
		Notificaciones.setBounds(325, 212, 154, 74);
		Notificaciones.setFont(new Font("Monospaced", Font.PLAIN, 11));
		Notificaciones.setEnabled(false);
		frame.getContentPane().add(Notificaciones);
		
		JTextArea RegTextAristas = new JTextArea();
		RegTextAristas.setBounds(1, 1, 462, 168);
		RegTextAristas.setEnabled(false);
		frame.getContentPane().add(RegTextAristas);
		
		JScrollPane scrollPane = new JScrollPane(RegTextAristas);
		scrollPane.setBounds(15, 25, 464, 170);
		frame.getContentPane().add(scrollPane);
		
		JScrollPane scrollPane_1 = new JScrollPane(Notificaciones);
		scrollPane_1.setBounds(325, 210, 154, 77);
		frame.getContentPane().add(scrollPane_1);
		
		//----------------------------  JBotton`s --------------------------
		
		BottonAddVert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CrearVertice();
				int CantVert = Graf.GetVertices();
				String CantVertStr = Integer.toString(CantVert);
				TextVertices.setText(CantVertStr);
			}
		});
		
		ButtonAddArista.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String Salida = "";
				String AristaOrigen = TextOrigen.getText();
				String AristaDestino= TextDestino.getText();
				String AristaDistancia = TextDistancia.getText();
				boolean AristaPeaje = LecturaPeaje(BottonPeaje);

				if(isNumeric(AristaOrigen) && isNumeric(AristaDestino) && isNumeric(AristaDistancia)){
					int IntOrigen = Integer.parseInt(AristaOrigen);
					int IntDestino = Integer.parseInt(AristaDestino);
					int IntDistancia = Integer.parseInt(AristaDistancia);
					int CantVert = Graf.GetVertices();
					if(RangoValido(IntOrigen,CantVert)&&RangoValido(IntDestino,CantVert)&&EsNumNatural(IntDistancia)){
						if(!CaminoBucle(IntOrigen,IntDestino)){
							Salida = "";
							Notificaciones.setText(Salida);
							CrearArista(IntOrigen-1, IntDestino-1, AristaPeaje, IntDistancia);
							Registro=Registro+"- Origen: "+IntOrigen+"  Distancia: "+IntDistancia+"  Destino: "+IntDestino+"  Peaje: "+AristaPeaje+"\n";
							RegTextAristas.setText(Registro);
							Salida = "- Arista Agregada.";
						}else{
							Salida = "- Arista Bucle.";
						}
					}else{
						Salida = Notif_Rango_Invalido(Salida, IntOrigen,IntDestino, IntDistancia, CantVert);
					}
				}else{
					Salida = Notif_No_Num(Salida, AristaOrigen, AristaDestino,AristaDistancia);
				}
				Notificaciones.setText(Salida);
			}
		});
		
		BottonAppAlg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Salida = "";
				String AlgOrigen = TextInicial.getText();
				String AlgDestino= TextFinal.getText();
				String LimPeajes= Max_Peajes.getText();
				if(isNumeric(AlgOrigen) && isNumeric(AlgDestino) && isNumeric(LimPeajes)){
					int IntOrigen = Integer.parseInt(AlgOrigen);
					int IntDestino = Integer.parseInt(AlgDestino);
					// Se suma 1, para que acepte peaje max 0.  
					int IntPeajes = Integer.parseInt(LimPeajes)+1;
					int CantVert = Graf.GetVertices();
					if(RangoValido(IntOrigen,CantVert)&&RangoValido(IntDestino,CantVert)&&EsNumNatural(IntPeajes)){
						// Volvemos a nuestro peaje Original restandole 1.
						IntPeajes = IntPeajes-1;
						// Tambien lo hacemos con Origen/Destino.
						IntOrigen = IntOrigen - 1;
						IntDestino = IntDestino - 1;
						if(!CaminoBucle(IntOrigen,IntDestino)){
							Salida = DevolverSolucion(Metodo, IntOrigen,IntDestino, IntPeajes);
						}else{
							Salida = "- Ya estas ahi :|\n  Costo 0.";
						}
					}else{
						Salida = Notif_Out_Range(Salida, IntOrigen, IntDestino,IntPeajes, CantVert);
					}
				}else{
					Salida = Notif_Not_Number(Salida, AlgOrigen, AlgDestino,LimPeajes);
				}
				Notificaciones.setText(Salida);
			}
		});
	
	}
	
	//-----------------------------------------------------------------------------
	//------------------------- Metodos De Data-Check/Notif -----------------------
	//-----------------------------------------------------------------------------

	private static boolean CaminoBucle(int Orig, int Dest){
		if(Orig==Dest){
			return true;
		}
		return false;
	}
	
	private static boolean RangoValido(int Elemento, int Tamaño){
		if(Tamaño==0 || Elemento<1 || Elemento>Tamaño){
			return false;
		}
		return true;
	}

	private static boolean EsNumNatural(int Numero){
		if(Numero>=0){
			return true;
		}
		return false;
	}
	
	private static boolean LecturaPeaje(JRadioButton Botton){
		if(Botton.isSelected()){
			return true;
		}
		return false;
	}
	
	private static boolean isNumeric(String cadena){
		try {
			Integer.parseInt(cadena);
			return true;
		} catch (NumberFormatException nfe){
			return false;
		}
	}
	
	private String Notif_No_Num(String Salida, String AristaOrigen,
			String AristaDestino, String AristaDistancia) {
		if(isNumeric(AristaOrigen)==false){
			Salida = Salida + "- Origen no es un\n  numero.\n";
		}
		if(isNumeric(AristaDestino)==false){
			Salida = Salida + "- Destino no es un\n  numero.\n";
		}
		if(isNumeric(AristaDistancia)==false){
			Salida = Salida + "- Distancia no es\n  un numero.";
		}
		return Salida;
	}
	
	private String Notif_Rango_Invalido(String Salida, int IntOrigen,
			int IntDestino, int IntDistancia, int CantVert) {
		if(RangoValido(IntOrigen,CantVert)==false){
			Salida = Salida + "- Origen fuera de\n  rango.\n";
		}
		if(RangoValido(IntDestino,CantVert)==false){
			Salida = Salida + "- Destino fuera de\n  rango.\n";
		}
		if(EsNumNatural(IntDistancia)==false){
			Salida = Salida + "- Distancia fuera de\n  rango.\n";
		}
		return Salida;
	}
	
	private String Notif_Out_Range(String Salida, int IntOrigen,
			int IntDestino, int IntPeajes, int CantVert) {
		if(RangoValido(IntOrigen,CantVert)==false){
			Salida = Salida + "- Inicio (s) fuera\n  de rango.\n";
		}
		if(RangoValido(IntDestino,CantVert)==false){
			Salida = Salida + "- Final (t) fuera\n  de rango.\n";
		}
		if(EsNumNatural(IntPeajes)==false){
			Salida = Salida + "- Peajes Max\n  fuera de rango.";
		}
		return Salida;
	}
	
	private String Notif_Not_Number(String Salida, String AlgOrigen,
			String AlgDestino, String LimPeajes) {
		if(isNumeric(AlgOrigen)==false){
			Salida = Salida + "- Inicio (s) no es\n  un numero.\n";
		}
		if(isNumeric(AlgDestino)==false){
			Salida = Salida + "- Final (t) no es\n  un numero.\n";
		}
		if(isNumeric(LimPeajes)==false){
			Salida = Salida + "- Peajes Max no es\n  un numero.";
		}
		return Salida;
	}
	
	//-----------------------------------------------------------------------------
	//----------------------------- Metodos De Creacion ---------------------------
	//-----------------------------------------------------------------------------

	public static void CrearVertice(){
		Graf.AgregarVertice();
	}
	
	public static void CrearArista(int Origen, int Destino, boolean Peaje, int Distancia){
		Tupla_Arista Tupla = new Tupla_Arista (Peaje,Distancia,Destino);
		Graf.AgregarArista(Origen, Tupla);
	}

	//-----------------------------------------------------------------------------
	//-------------------------- Metodos De Analisis Final ------------------------
	//-----------------------------------------------------------------------------

	private String DevolverSolucion(ModGraf_Dijsktra Metodo,int IntOrigen, int IntDestino, int IntPeajes) {
		String Salida;
		Grafo Nuevo_Graf = Metodo.ModificarGrafo(IntPeajes, Graf, IntOrigen);
		ArrayList<Etiqueta> Conj_Etiquetas = Metodo.Dijkstra(Nuevo_Graf, IntOrigen);
		Etiqueta Etiqueta_Min = EtiquetaMinima(IntPeajes, Conj_Etiquetas, IntDestino);
		String Recorrer = SolucionRecorrido(Etiqueta_Min);
		Salida = " - Distancia Min a\n   recorrer: " + Recorrer + ".\n";
		ArrayList<Integer> PreSol = AnalizarSoluciones(IntPeajes, Conj_Etiquetas, IntOrigen, IntDestino);
		ArrayList<Integer> Sol =InvertirLista(PreSol);
		Salida = Salida + " - Viajes a Destino:\n  " + SolucionCadena(Sol);
		return Salida;
	}

	private static ArrayList<Integer> AnalizarSoluciones(int LimitePeajes,ArrayList<Etiqueta> Soluciones,int Origen,int Destino){
		ArrayList<Integer> ListRet = new ArrayList<Integer>();
		Etiqueta EtiquetaMin = EtiquetaMinima(LimitePeajes,Soluciones, Destino);
		if(EtiquetaMin!=null){
			int Niveles = LimitePeajes+1;
			int CantVert = Soluciones.size()/Niveles;
			Etiqueta EtiqPos = EtiquetaMin;
			while(EtiqPos!=null){
				int IndiceEtiq = Soluciones.indexOf(EtiqPos);
				while(IndiceEtiq>=CantVert){
					IndiceEtiq=IndiceEtiq-CantVert;
				}
				ListRet.add(IndiceEtiq);
				EtiqPos = Soluciones.get(EtiqPos.GetDestino());
			}
			ListRet.add(Origen);
			return InvertirLista(ListRet);
		}else{
			return ListRet;
		}
	}

	//-----------------------------------------------------------------------------
		
		private static Etiqueta EtiquetaMinima(int MaxPeajes,ArrayList<Etiqueta> Resul, int Destino){
			Etiqueta EtiquetaMenor=Resul.get(Destino);
			int CantNiveles=MaxPeajes+1;
			int Corrimiento=Resul.size()/CantNiveles;
			while(Destino<Resul.size()){
				if (EtiquetaMenor==null){
					EtiquetaMenor=Resul.get(Destino);
				}else{
					if(Resul.get(Destino)==null){
						
					}else{
						if(Resul.get(Destino).GetDistancia()<EtiquetaMenor.GetDistancia()){
							EtiquetaMenor=Resul.get(Destino);
						}
					}
				}
				Destino=Destino+Corrimiento;
			}
			return EtiquetaMenor;
		}
		
	//-----------------------------------------------------------------------------
		
		private static ArrayList<Integer> InvertirLista(ArrayList<Integer> Invertida){
			ArrayList<Integer> Desinvertida = new ArrayList<Integer>();
			for(int i=Invertida.size()-1;i>=0;i--){
				Desinvertida.add(Invertida.get(i));
			}
			return Desinvertida;
		}
		
	//-----------------------------------------------------------------------------
		
		private static String SolucionCadena(ArrayList<Integer> Sol){
			String Cadena = "-";
			for(int i=Sol.size()-1;i>=0;i--){
				int Camino = Sol.get(i)+1;
				Cadena = Cadena + Camino +"-";
			}
			return Cadena;
		}

	//-----------------------------------------------------------------------------
			
			private static String SolucionRecorrido(Etiqueta SolEtiq){
				if(SolEtiq!=null){
					int DistEnt = SolEtiq.GetDistancia();
					return Integer.toString(DistEnt);
				}else{
					return "∞";
				}
			}
}
