package Capa_Aplicacion;

import java.util.ArrayList;

import Capa_Datos.Grafo;

public interface Interfaz_RyF {
	
	public ArrayList<Etiqueta> Dijkstra(Grafo Grafo, int VertInicial);
	public Grafo ModificarGrafo(int LimitePeajes, Grafo GrafOld, int VertInicial);
	
}
