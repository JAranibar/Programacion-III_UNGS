package Capa_Aplicacion;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

import Capa_Datos.Grafo;
import Capa_Datos.Tupla_Arista;

public class ModGraf_Dijsktra implements Interfaz_RyF{
	
	
	
	@Override
	//----------------------------------------------------------------------------------------
	//----------------------------------- Modificar Grafo ------------------------------------
	//----------------------------------------------------------------------------------------
		
	public Grafo ModificarGrafo(int LimitePeajes, Grafo GrafOld, int VertInicial){
		
		int CantNewVertices = (LimitePeajes+1)*GrafOld.GetVertices();
		Grafo NewGrafo = new Grafo();
		
		AgregarVertices(CantNewVertices, NewGrafo);
		
		CopiarAristas(LimitePeajes, GrafOld, NewGrafo);
		
		// Relacionamos los niveles y eliminamos aristas.
		
		// 1� Creamos un ArrayList de ArrayList<Integer> que contiene todas las relaciones.
		ArrayList<ArrayList<Integer>> Arritas = AgendarRelaciones(CantNewVertices, NewGrafo);
		
		// 2� Relacionamos los SubGrafos.
		int CantVerticesOriginal = GrafOld.GetVertices();
		RelacionarSubGrafos(VertInicial,Arritas,NewGrafo,CantVerticesOriginal);
		
		return NewGrafo;
	}
	
	//----------------------- Metodo usado en Modificar Grafo -----------------------------------------
	
	private void AgregarVertices(int CantNewVertices, Grafo NewGrafo) {
		for(int i=0; i<CantNewVertices; i++){
			NewGrafo.AgregarVertice();
		}
	}
	
	private void CopiarAristas(int LimitePeajes, Grafo GrafOld, Grafo NewGrafo) {
		for(int VertPointer=0; VertPointer<GrafOld.GetVertices(); VertPointer++){
			HashSet<Tupla_Arista> Relaciones = GrafOld.GetAristas(VertPointer);
			Iterator<Tupla_Arista> it = Relaciones.iterator();
			while(it.hasNext()){
				Tupla_Arista Relacion = it.next();
				int Origen=VertPointer;
				int Destino = Relacion.GetDestino();
				if(!NewGrafo.CheckearExistenciaArista(Origen, Destino)){
					// Agrega arista como Limite de peajes, incluyendo al Grafo Nivel 0.
					int Distancia = Relacion.GetDistancia();
					boolean Peaje = Relacion.GetPeaje();
					int CantVertGrafo=GrafOld.GetVertices();
					for (int i=0;i<=LimitePeajes;i++){
						Tupla_Arista Tupla = new Tupla_Arista(Peaje,Distancia, Destino);
						NewGrafo.AgregarArista(Origen,Tupla);
						Origen=Origen+CantVertGrafo;
						Destino=Destino+CantVertGrafo;
					}
				}
			}
		}
	}

	private ArrayList<ArrayList<Integer>> AgendarRelaciones(
			int CantNewVertices, Grafo NewGrafo) {
		ArrayList<ArrayList<Integer>> Vertices = new ArrayList<ArrayList<Integer>>();
		
		for(int i=0; i<CantNewVertices; i++){
			ArrayList<Integer> Destinos = new ArrayList<Integer>();
			HashSet<Tupla_Arista> Tuplas = NewGrafo.GetAristas(i);
			Iterator<Tupla_Arista> iterador = Tuplas.iterator();
			while(iterador.hasNext()){
				Tupla_Arista Relacion = iterador.next();
				int Destino = Relacion.GetDestino();
				Destinos.add(Destino);	
			}
			Vertices.add(Destinos);
		}
		return Vertices;
	}
	
	private static void RelacionarSubGrafos(int VertPosicionado,ArrayList<ArrayList<Integer>> Relaciones, Grafo NewG, int Corrimiento){		
		if(Relaciones.get(VertPosicionado).size()==0){
			return;
		}else{
			for(int i=0;i<Relaciones.get(VertPosicionado).size();i++){
				// Si Arista tiene peaje...
				if(NewG.CheckearExistenciaArista(VertPosicionado, Relaciones.get(VertPosicionado).get(i))){
					if(NewG.PeajeArista(VertPosicionado, Relaciones.get(VertPosicionado).get(i))){
						int NewDestino = Relaciones.get(VertPosicionado).get(i) + Corrimiento;
						//Check rango del destino nuevo
						if(NewDestino<NewG.GetVertices()){
							boolean Peaje = NewG.PeajeArista(VertPosicionado, Relaciones.get(VertPosicionado).get(i));
							int Distancia = NewG.DistanciaArista(VertPosicionado, Relaciones.get(VertPosicionado).get(i));
							Tupla_Arista NewTup = new Tupla_Arista(Peaje,Distancia,NewDestino);
							NewG.EliminarArista(VertPosicionado, Relaciones.get(VertPosicionado).get(i));
							NewG.AgregarArista(VertPosicionado, NewTup);					
							RelacionarSubGrafos(NewDestino,Relaciones, NewG, Corrimiento);
						}else{
							NewG.EliminarArista(VertPosicionado, Relaciones.get(VertPosicionado).get(i));
						}
					}else{
						RelacionarSubGrafos(Relaciones.get(VertPosicionado).get(i),Relaciones, NewG, Corrimiento);
					}	
				}
			}
		}
	}

	
	
	
	
	
	
	
	@Override
	//----------------------------------------------------------------------------------------
	//--------------------------------------- Dijkstra ---------------------------------------
	//----------------------------------------------------------------------------------------
	
	public ArrayList<Etiqueta> Dijkstra(Grafo Grafo, int VertInicial){
		
		int NodoPos = VertInicial;
		
		ArrayList <Integer> Vistos = new ArrayList<Integer>();	
		ArrayList <Boolean> Marcados = new ArrayList<Boolean>();			
	
		for(int i=0; i<Grafo.GetVertices(); i++){
			Marcados.add(false);	
		}
		Marcados.set(NodoPos, true);
		
		ArrayList<Etiqueta> Resultado = new ArrayList<Etiqueta>();
		for(int i=0; i<Grafo.GetVertices(); i++){
			Resultado.add(null);	
		}

		while (QuedanRelacionar(Grafo, NodoPos, Vistos)){
			HashSet<Tupla_Arista> Relaciones = Grafo.GetAristas(NodoPos);
			Iterator<Tupla_Arista> it = Relaciones.iterator();
			while(it.hasNext()){
				ActualizarEtiquetas(VertInicial, NodoPos, Vistos, Resultado, it);
			}
			NodoPos = MarcarYPosionarVert(NodoPos, Vistos, Marcados,Resultado);
		}
		return Resultado;
	}

	//-----------------------------Metodos usados en Dijkstra------------------------------------------ 

	private boolean QuedanRelacionar(Grafo Grafo, int NodoPos,ArrayList<Integer> Vistos) {
		HashSet<Tupla_Arista> Aristas = Grafo.GetAristas(NodoPos);
		if(Aristas.size()==0 && Vistos.size()==0){
			return false;
		}
		return true;
	}

	private void ActualizarEtiquetas(int VertInicial, int NodoPos, ArrayList<Integer> Vistos, ArrayList<Etiqueta> Resultado, Iterator<Tupla_Arista> it) {
		Tupla_Arista Relacion = it.next();
		int NodoRel=Relacion.GetDestino();
		int DistanciaRel=Relacion.GetDistancia();
		if(Resultado.get(NodoRel)==null && NodoRel!=VertInicial){
			// Si se encuentra posicionada en el nodo Inicial, Etiqueta Automaticamente
			// Si no, por el condicional anterior el nodoRelacion es un null, que es 
			// distinto de Inicial, e etiqueta el nodo. 
			if(Resultado.get(NodoPos)==null){
				Etiquetar_Vertice(NodoRel,NodoPos,DistanciaRel,Resultado);
				Vistos.add(NodoRel);	
			}else{
				Etiqueta Etiposicionada = GetEtiqueta(NodoPos, Resultado);
				int NewDistancia = Etiposicionada.Distancia+DistanciaRel;
				Etiqueta EtiFutura = new Etiqueta(NewDistancia, NodoPos);
				Resultado.set(NodoRel, EtiFutura);
				Vistos.add(NodoRel);
			}
		}else{
			if (Vistos.contains(NodoRel)==true){
				//comparar etiquetas...
				Etiqueta Etiposicionada = GetEtiqueta(NodoPos, Resultado);
				int NewDis = Etiposicionada.Distancia+DistanciaRel;
				Etiqueta EtiFutura = new Etiqueta(NewDis, NodoPos);
				Etiqueta EtiActual = GetEtiqueta(NodoRel, Resultado);
				if(EtiFutura.GetDistancia()<EtiActual.GetDistancia()){
					Resultado.set(NodoRel, EtiFutura);
				}
			}
		}
	}

	private int MarcarYPosionarVert(int NodoPos, ArrayList<Integer> Vistos, ArrayList<Boolean> Marcados, ArrayList<Etiqueta> Resultado) {
		if (!(Vistos.size()==0)){
			int NodoMin = Vistos.get(0);
			for(int i=0;i<Vistos.size();i++){
				int NodoFuturoMin = Vistos.get(i);
				if(EtiquetaMenor(Resultado.get(NodoMin),Resultado.get(NodoFuturoMin))){
					NodoMin = NodoFuturoMin;
				}
			}
			Marcados.set(NodoMin, true);
			Vistos.remove(Vistos.indexOf(NodoMin));
			NodoPos = NodoMin;
		}
		return NodoPos;
	}
	
	private static void Etiquetar_Vertice(int NodoAetiquetar, int Antecesor, int Distancia, ArrayList<Etiqueta> Resul){
		Etiqueta et = new Etiqueta(Distancia, Antecesor);
		Resul.set(NodoAetiquetar, et);
	}
	
	private static Etiqueta GetEtiqueta(int indice, ArrayList<Etiqueta> Etiquetas){
		return Etiquetas.get(indice);
	}
	
	private static boolean EtiquetaMenor(Etiqueta min, Etiqueta pos){
		if(pos.GetDistancia()<min.GetDistancia()){
			return true;	
		}
		return false;
	}

}
