package Capa_Aplicacion;

public class Etiqueta {

	public int Distancia;
	int Destino;
	
	public Etiqueta(int Dis, int Des){
		this.Distancia=Dis;
		this.Destino=Des;
	}
	
	public int GetDistancia(){
		return this.Distancia;
	}
	
	public int GetDestino(){
		return this.Destino;
	}
	
	public void SetDistancia(int Dis){
		this.Distancia=Dis;
	}
	
	public void SetDestino(int Des){
		this.Destino=Des;
	}
	
}
