package Capa_de_Negocio;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

import Capa_de_Datos.Aulas;
import Capa_de_Datos.Materia;

public class Algoritmo_Goloso {

	public Algoritmo_Goloso() {
		
	}

	public void AlgoritmoGoloso(ArrayList<Materia> Materias, Aulas Asignaturas){
		OrdenarPorDiferencial(Materias);
		for(int i=0; i<Materias.size(); i++){
			AsignarAula(Materias.get(i),Asignaturas);
		}
		return;
	}
	
	private static void OrdenarPorDiferencial(ArrayList<Materia> Desordenado){
		ArrayList<Materia> MateriasOrdenadas = new ArrayList<Materia>();
		if(Desordenado.size()==0){
			return;
		}
		while(Desordenado.size()!=1){
			Materia DeltaMin = Desordenado.get(0);
			int DiffMin = DeltaMin.getHoraFin() - DeltaMin.getHoraInicio();
			for (int i=1; i<Desordenado.size(); i++){
				Materia FuturoDeltaMin = Desordenado.get(i);
				int futDiffMin = FuturoDeltaMin.getHoraFin() - FuturoDeltaMin.getHoraInicio();
				if(futDiffMin<=DiffMin){
					DeltaMin = Desordenado.get(i);
				}
			}
			MateriasOrdenadas.add(DeltaMin);
			Desordenado.remove(Desordenado.indexOf(DeltaMin));
		}
		Materia DeltaMin = Desordenado.get(0);
		MateriasOrdenadas.add(DeltaMin);
		Desordenado.remove(Desordenado.indexOf(DeltaMin));
		
		for (int i=0; i<MateriasOrdenadas.size(); i++){
			Materia Mate = MateriasOrdenadas.get(i);
			Desordenado.add(Mate);
		}

		return;
	}

	private static void AsignarAula(Materia materia,Aulas aulas){
		int indice = 0;
		boolean llaveDeBorde=true;
		while(indice<aulas.CantidadAulas()&&llaveDeBorde){
			//Recorremos las materias del indice de esa aula.
			HashSet<Materia> Lista_Materias = aulas.GetMaterias(indice);
			Iterator<Materia> it = Lista_Materias.iterator();
			boolean MateriaAceptable=true;
			while(it.hasNext() && MateriaAceptable){
				Materia Asignada = it.next(); 
				if(SuperPosicion(Asignada,materia)){
					MateriaAceptable=false;
				}
			}	
			if(MateriaAceptable){
				aulas.AgregarMateria(indice, materia);
				llaveDeBorde=false;
			}
			indice++;	
		}
		if(llaveDeBorde){
			aulas.AgregarAula();
			int UltimoIndice = aulas.CantidadAulas()-1;
			aulas.AgregarMateria(UltimoIndice, materia);
		}
		
	}

	private static boolean SuperPosicion(Materia YaAsignada, Materia aAsignar){
		if((aAsignar.getHoraInicio()<YaAsignada.getHoraInicio() && aAsignar.getHoraFin()<=YaAsignada.getHoraInicio())
			||(aAsignar.getHoraInicio()>=YaAsignada.getHoraFin() && aAsignar.getHoraFin()>YaAsignada.getHoraFin())){
			return false;
		}
		return true;
	}
	
}
