package Capa_de_Negocio;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Capa_de_Datos.MateriasJSON;

public class CheckData {

	public CheckData() {
	}

	public boolean CodigoValido(MateriasJSON Mat, String CodAEvaluar){
		if(CodigoRepetido(Mat,CodAEvaluar)){
			return false;
		}
		if(ExpresionCorrecta(CodAEvaluar)){
			return true;	
		}
		return false;
	}
	
	public boolean CodigoRepetido(MateriasJSON Materias, String CodAEvaluar){
		for (int i=0; i<Materias.Tama�o(); i++){
			String CodigoIndice=Materias.dame(i).getCodigo();
			if(CodigoIndice.equals(CodAEvaluar)){
				return true;
			}
		}
		return false;
	}
	
	public boolean ExpresionCorrecta(String Codigo){
		// Quiere decir que acepta 2 Caracteres del alfabeto mayuscula
		// o miniscula luego un "-" y por ultimo 2 digitos.
		
		Pattern patter = Pattern.compile("([a-z]|[A-Z]){2}-[0-9]{2}");   
		Matcher masche = patter.matcher(Codigo);
		
		if (masche.matches()) {
	         return true;
	     } else {
	         return false;
	     }
	}
	
	//-------------------------------------------------------------------
	
	public boolean HorarioValido(String Inicio, String Fin){
		if(EsUnNumero(Inicio)&&EsUnNumero(Fin)){
			if(NumeroEnRango(Inicio)&&NumeroEnRango(Fin)){
				if(EsConsistente(Inicio,Fin)){
					return true;	
				}
			}
		}
		return false;
	}
	
	public boolean EsUnNumero(String Numero){
		try {
			Integer.parseInt(Numero);
			return true;
		} catch (NumberFormatException nfe){
			return false;
		}
	}
	
	public boolean NumeroEnRango(String Numero){
		int Num = Integer.parseInt(Numero);
		if(Num>=8 && Num<=22){
			return true;
		}
		return false;
	}
	
	public boolean EsConsistente(String Inicio, String Fin){
		int NumI = Integer.parseInt(Inicio);
		int NumF = Integer.parseInt(Fin);
		if(NumI<NumF){
			return true;
		}
		return false;
	}
	
}
