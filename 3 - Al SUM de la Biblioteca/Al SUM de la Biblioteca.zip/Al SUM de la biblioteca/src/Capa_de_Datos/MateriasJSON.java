package Capa_de_Datos;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


public class MateriasJSON {

	private ArrayList<Materia> Materias;
	
	public MateriasJSON() {
		Materias = new ArrayList<Materia>();
	}
	
	public void AgregarMateria(Materia Materia){
		Materias.add(Materia);
	}

	public void EliminarMateria(Materia M){
		Materias.remove(Materias.indexOf(M));
	}
	
	public int Tama�o(){
		return Materias.size();
	}
	
	public Materia dame(int indice){
		return Materias.get(indice);
	}

	public Materia BuscarMateriaPorCodigo(String Codigo){
		for (int i=0; i<Materias.size(); i++){
			String CodigoIndice=Materias.get(i).getCodigo();
			if(CodigoIndice.equals(Codigo)){
				return Materias.get(i);
			}
		}
		return null;
	}
	
	public void OrdenarPorHorario(){
		ArrayList<Materia> MateriasOrdenadas = new ArrayList<Materia>();
		if(this.Materias.size()==0){
			return;
		}
		while(this.Materias.size()!=1){
			Materia HorarioMenor = this.Materias.get(0);
			int Min = HorarioMenor.getHoraInicio();
			for (int i=1; i<this.Materias.size(); i++){
				Materia FuturoMenor = this.Materias.get(i);
				int futMin = FuturoMenor.getHoraInicio();
				if(futMin<Min){
					HorarioMenor = this.Materias.get(i);
				}
			}
			MateriasOrdenadas.add(HorarioMenor);
			this.Materias.remove(this.Materias.indexOf(HorarioMenor));
		}
		Materia DeltaMin = this.Materias.get(0);
		MateriasOrdenadas.add(DeltaMin);
		this.Materias.remove(this.Materias.indexOf(DeltaMin));
		
		for (int i=0; i<MateriasOrdenadas.size(); i++){
			Materia Mate = MateriasOrdenadas.get(i);
			this.Materias.add(Mate);
		}
		return;
	}
	
	public boolean CheckearExistenciaMateria(Materia M){
		if(Materias.contains(M)){
			return true;
		}
		return false;
	}
	
	public boolean CheckExistenciaPorCodigo(String Codigo){
		for (int i=0; i<Materias.size(); i++){
			String CodigoIndice=Materias.get(i).getCodigo();
			if(CodigoIndice.equals(Codigo)){
				return true;
			}
		}
		return false;
	}
	
	public String generarJSONPretty(){
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String json = gson.toJson(this);
		return json;
	}
	
	public void generarJSON(String json, String archivo){
		try{
			FileWriter writer = new FileWriter(archivo);
			writer.write(json);
			writer.close();
		}catch (IOException e){
			e.printStackTrace();
		}
	}
	
	private static MateriasJSON leerJSON(String archivo){
		Gson gson = new Gson();
		MateriasJSON ret = null;
		try {
			BufferedReader br = new BufferedReader(new FileReader(archivo));
			ret = gson.fromJson(br, MateriasJSON.class);
		}catch (IOException e){
			e.printStackTrace();
		}
		return ret;
	}
	
	public MateriasJSON CopiarArchivoJSON(String Nombre) {
		MateriasJSON MATERIAS= new MateriasJSON();
		MateriasJSON Materias = MateriasJSON.leerJSON(Nombre);
		for (int i=0; i<Materias.Tama�o(); i++){
			MATERIAS.AgregarMateria(Materias.dame(i));
		}
		return MATERIAS;
	}
	
	public ArrayList<Materia> CopiarArchivoArrayList(MateriasJSON MatJSON){
		ArrayList<Materia> NuevoArray = new ArrayList<Materia>();
		for (int i=0; i<MatJSON.Tama�o(); i++){
			NuevoArray.add(MatJSON.dame(i));
		}
		return NuevoArray;
	}
	
	public String LeerArchivoJSON(String Nombre) {
		String MATERIAS="";
		MateriasJSON Materias = MateriasJSON.leerJSON(Nombre);
		for (int i=0; i<Materias.Tama�o(); i++){
			String N=Materias.dame(i).getNombre();
			String C=Materias.dame(i).getCodigo();
			int HI=Materias.dame(i).getHoraInicio();
			int HF=Materias.dame(i).getHoraFin();
			MATERIAS = MATERIAS +"- Materia: "+N+"\t - Cod.: "+C+"  - Horario: "+HI+" a "+HF+" \n";
		}
		return MATERIAS;
	}
	
}
