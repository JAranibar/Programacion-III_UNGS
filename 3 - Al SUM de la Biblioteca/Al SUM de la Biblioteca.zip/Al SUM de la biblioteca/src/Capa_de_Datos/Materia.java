package Capa_de_Datos;
public class Materia {

	private String Nombre;
	private String Codigo;
	private int HoraInicio;
	private int HoraFin;
	
	public Materia(String Nom, String Cod, int HoraI, int HoraF){
		this.Nombre=Nom;
		this.Codigo=Cod;
		this.HoraInicio=HoraI;
		this.HoraFin=HoraF;
	}
	
	public String getNombre(){
		return this.Nombre;
	}

	public String getCodigo(){
		return this.Codigo;
	}

	public int getHoraInicio(){
		return this.HoraInicio;
	}

	public int getHoraFin(){
		return this.HoraFin;
	}
	
}
