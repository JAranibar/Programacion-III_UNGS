package Capa_de_Datos;

import static org.junit.Assert.*;

import org.junit.Test;

public class MateriasJSONTest {

	@Test
	public void testExistenciaMateria() {
		Materia M1 = new Materia("Matematica I","jr10",5,10);
		Materia M2 = new Materia("Matematica II","jr10",10,15);
		MateriasJSON Materias = new MateriasJSON();
		Materias.AgregarMateria(M1);
		Materias.AgregarMateria(M2);
		assertTrue(Materias.CheckearExistenciaMateria(M1));
	}

	@Test
	public void testInexistenciaMateria() {
		Materia M1 = new Materia("Matematica I","jr10",5,10);
		Materia M2 = new Materia("Matematica II","jr10",10,15);
		Materia M3 = new Materia("Matematica III","jr10",15,20);
		MateriasJSON Materias = new MateriasJSON();
		Materias.AgregarMateria(M1);
		Materias.AgregarMateria(M2);
		Materias.AgregarMateria(M3);
		Materias.EliminarMateria(M2);
		assertFalse(Materias.CheckearExistenciaMateria(M2));
	}
	
	@Test
	public void testCantidadMaterias() {
		Materia M1 = new Materia("Matematica I","jr10",5,10);
		Materia M2 = new Materia("Matematica II","jr10",10,15);
		Materia M3 = new Materia("Matematica III","jr10",15,20);
		MateriasJSON Materias = new MateriasJSON();
		Materias.AgregarMateria(M1);
		Materias.AgregarMateria(M2);
		Materias.AgregarMateria(M3);
		assertEquals(3,Materias.Tama�o());
	}

	@Test
	public void testExistenciaPorCodigo() {
		Materia M1 = new Materia("Matematica I","jr20",5,10);
		Materia M2 = new Materia("Matematica II","jr10",10,15);
		Materia M3 = new Materia("Matematica III","jr30",15,20);
		MateriasJSON Materias = new MateriasJSON();
		Materias.AgregarMateria(M1);
		Materias.AgregarMateria(M2);
		Materias.AgregarMateria(M3);
		assertTrue(Materias.CheckExistenciaPorCodigo("jr10"));
	}
	
}
