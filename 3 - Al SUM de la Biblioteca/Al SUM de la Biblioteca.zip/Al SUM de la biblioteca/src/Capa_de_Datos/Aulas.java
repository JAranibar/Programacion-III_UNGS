package Capa_de_Datos;
import java.util.ArrayList;
import java.util.HashSet;

public class Aulas {

	private ArrayList<HashSet<Materia>> Aulas;

	public Aulas() {
		Aulas = new ArrayList<HashSet<Materia>>(); 
	}

	public int CantidadAulas(){
		return Aulas.size();
	}
	
	public void AgregarAula(){
		Aulas.add(new HashSet<Materia>());
	}
	
	public void AgregarMateria(int Indice,Materia Mat){
		Aulas.get(Indice).add(Mat);
	} 
	
	public HashSet<Materia> GetMaterias(int Aula){
		return Aulas.get(Aula);
	}
}
