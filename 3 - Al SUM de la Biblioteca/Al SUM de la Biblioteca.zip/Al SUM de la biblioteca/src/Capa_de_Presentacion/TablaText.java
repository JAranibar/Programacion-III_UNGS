package Capa_de_Presentacion;

import java.awt.Color;
import java.awt.Font;
import java.util.HashSet;
import java.util.Iterator;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import Capa_de_Datos.Aulas;
import Capa_de_Datos.Materia;
import Capa_de_Datos.MateriasJSON;

public class TablaText {

	private JTable Tabla;
	
	public TablaText(JFrame frame) {
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setViewportBorder(new TitledBorder(null, "Asignaciones", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		scrollPane_2.setBounds(370, 126, 303, 224);
		frame.getContentPane().add(scrollPane_2);
		
		Tabla = new JTable();
		Tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		Tabla.setBackground(Color.LIGHT_GRAY);
		Tabla.setForeground(Color.BLUE);
		scrollPane_2.setViewportView(Tabla);
	
		JLabel lblAulasAsignadas = new JLabel("Aulas Asignadas :");
		lblAulasAsignadas.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblAulasAsignadas.setHorizontalAlignment(SwingConstants.LEFT);
		lblAulasAsignadas.setBounds(370, 99, 112, 14);
		frame.getContentPane().add(lblAulasAsignadas);
	}
	
	public void CaracterizarTabla(DefaultTableModel model){
		Tabla.getColumnModel().getColumn(0).setPreferredWidth(270);
		Tabla.getColumnModel().getColumn(1).setPreferredWidth(75);
		Tabla.getColumnModel().getColumn(2).setPreferredWidth(75);
		Tabla.getColumnModel().getColumn(3).setPreferredWidth(50);
		//desabilita la edicion del tama�o de la celda.
		Tabla.getColumnModel().getColumn(0).setResizable(false);
		Tabla.getColumnModel().getColumn(1).setResizable(false);
		Tabla.getColumnModel().getColumn(2).setResizable(false);
		Tabla.getColumnModel().getColumn(3).setResizable(false);
		//desabilita la edicion de mover la celda.
		//Tabla.getTableHeader().setReorderingAllowed(false);
	}
	
	public void MostrarAsignaciones(Aulas Comisio) {
		@SuppressWarnings("serial")
		DefaultTableModel model = new DefaultTableModel(){
	        public boolean isCellEditable(int rowIndex, int vColIndex) {
	            return false;
	        }}; //return false: Desabilitar edici�n de celdas.
		
		model.addColumn("                 Materia"); 
		model.addColumn("Codigo");
		model.addColumn("Horario");
		model.addColumn("Aula");
		Tabla.setModel(model);
		CaracterizarTabla(model);
		SetearTabla(model,Comisio);
		CentrarTabla();
	}
	
	private void SetearTabla(DefaultTableModel Model , Aulas Comisiones){
		for(int i=0; Comisiones.CantidadAulas()>i; i++){
			String Aula = Integer.toString(i+1);
			HashSet<Materia> Relaciones = Comisiones.GetMaterias(i);
			Iterator<Materia> it = Relaciones.iterator();
			MateriasJSON MateriasDelAula = new MateriasJSON();
			while(it.hasNext()){
				Materia M = it.next();
				MateriasDelAula.AgregarMateria(M);
			}
			MateriasDelAula.OrdenarPorHorario();
			for (int h=0;h<MateriasDelAula.Tama�o();h++){
				String Nombre = MateriasDelAula.dame(h).getNombre();
				String Codigo = MateriasDelAula.dame(h).getCodigo();
				String HoraI = Integer.toString(MateriasDelAula.dame(h).getHoraInicio());
				String HoraF = Integer.toString(MateriasDelAula.dame(h).getHoraFin());
				Model.addRow(new String[]  {Nombre, Codigo, HoraI+" a "+HoraF, Aula });
			}
		}
	}
	
	private void CentrarTabla(){	  
        DefaultTableCellRenderer modelocentrar = new DefaultTableCellRenderer();
        modelocentrar.setHorizontalAlignment(SwingConstants.CENTER);
        Tabla.getColumnModel().getColumn(0).setCellRenderer(modelocentrar);
        Tabla.getColumnModel().getColumn(1).setCellRenderer(modelocentrar);
        Tabla.getColumnModel().getColumn(2).setCellRenderer(modelocentrar);
        Tabla.getColumnModel().getColumn(3).setCellRenderer(modelocentrar);
	 }
}
