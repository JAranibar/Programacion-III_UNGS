package Capa_de_Presentacion;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.UIManager;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


import java.awt.Font;
import java.util.ArrayList;

import javax.swing.SwingConstants;

import Capa_de_Datos.Aulas;
import Capa_de_Datos.Materia;
import Capa_de_Datos.MateriasJSON;
import Capa_de_Negocio.Algoritmo_Goloso;
import Capa_de_Negocio.CheckData;

import javax.swing.JInternalFrame;
import javax.swing.border.LineBorder;
import javax.swing.JSeparator;

public class Entorno_Grafico {

	private JFrame frame;
	private JTextField MateriaText;
	private JTextField CodigoText;
	private JTextField HoraIniText;
	private JTextField HoraFinText;
	private JTextField removeMateriaText;
	
	private MateriasJSON ArchivoPosicionado;
	private Aulas Comisiones;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
					Entorno_Grafico window = new Entorno_Grafico();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Entorno_Grafico() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */

	private void initialize() {

		MateriasJSON MateriasJson= new MateriasJSON();
		Algoritmo_Goloso Algoritmo = new Algoritmo_Goloso();
		CheckData Checkeo = new CheckData();
		
		Comisiones = new Aulas();
		
		frame = new JFrame();
		frame.setBounds(100, 100, 700, 550);
		Image icon = new ImageIcon(getClass().getResource("/Imagen/Icono.png")).getImage();
	    frame.setIconImage(icon);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setBackground(Color.ORANGE);
		frame.setTitle("Al SUM de la biblioteca");
		
		Notificaciones Avisos = new Notificaciones(frame);
		TablaText Asignaciones = new TablaText(frame);

		JInternalFrame SubVentana = new JInternalFrame("Checkeo de Seguridad");
		SubVentana.setBorder(new LineBorder(null));
		SubVentana.getContentPane().setBackground(Color.GRAY);
		SubVentana.setBounds(62, 166, 221, 144);
		frame.getContentPane().add(SubVentana);
		frame.setResizable(false); 
		SubVentana.getContentPane().setLayout(null);

		JLabel lblEstaSeguro = new JLabel("\u00BF Esta Seguro de");
		lblEstaSeguro.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblEstaSeguro.setHorizontalAlignment(SwingConstants.CENTER);
		lblEstaSeguro.setBounds(0, 11, 217, 33);
		SubVentana.getContentPane().add(lblEstaSeguro);
		
		JLabel lblEliminarTodo = new JLabel("eliminar todo ?");
		lblEliminarTodo.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblEliminarTodo.setHorizontalAlignment(SwingConstants.CENTER);
		lblEliminarTodo.setBounds(0, 45, 219, 23);
		SubVentana.getContentPane().add(lblEliminarTodo);
		
		JButton ButtSiVentInterna = new JButton("Si");
		ButtSiVentInterna.setBackground(Color.GREEN);
		ButtSiVentInterna.setBounds(24, 80, 67, 23);
		SubVentana.getContentPane().add(ButtSiVentInterna);
		
		JButton ButtNoVentInterna = new JButton("No");
		ButtNoVentInterna.setBackground(Color.RED);
		ButtNoVentInterna.setBounds(128, 80, 67, 23);
		SubVentana.getContentPane().add(ButtNoVentInterna);
		
		ArchivoText Archivo = new ArchivoText(frame);
		
		JLabel Presentacion = new JLabel();
		ImageIcon Present = new ImageIcon(this.getClass().getResource("/Imagen/Titulo.png"));
		Presentacion.setBounds(237,10,220,78);
		Presentacion.setIcon(Present);
		frame.getContentPane().add(Presentacion);
		
		JLabel lblMateria = new JLabel("Materia :");
		lblMateria.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblMateria.setForeground(new Color(0, 102, 0));
		lblMateria.setBounds(27, 378, 58, 14);
		frame.getContentPane().add(lblMateria);
		
		JLabel lblCodigo = new JLabel("Codigo :");
		lblCodigo.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblCodigo.setForeground(new Color(0, 102, 0));
		lblCodigo.setBounds(124, 365, 51, 14);
		frame.getContentPane().add(lblCodigo);
		
		JLabel lblHorario = new JLabel("Horario\r\n :");
		lblHorario.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblHorario.setForeground(new Color(0, 102, 0));
		lblHorario.setBounds(213, 365, 58, 14);
		frame.getContentPane().add(lblHorario);

		JLabel lblIni = new JLabel("Ini.");
		lblIni.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblIni.setForeground(new Color(0, 102, 0));
		lblIni.setBounds(192, 408, 29, 14);
		frame.getContentPane().add(lblIni);
		
		JLabel lblFin = new JLabel("Fin.");
		lblFin.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblFin.setForeground(new Color(0, 102, 0));
		lblFin.setBounds(249, 408, 29, 14);
		frame.getContentPane().add(lblFin);
		
		JLabel lblCodigo_1 = new JLabel("Codigo :");
		lblCodigo_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblCodigo_1.setForeground(Color.RED);
		lblCodigo_1.setBounds(27, 463, 51, 14);
		frame.getContentPane().add(lblCodigo_1);

		JLabel lblEjAa = new JLabel("Ej.: Aa-10");
		lblEjAa.setForeground(Color.GRAY);
		lblEjAa.setBounds(124, 384, 51, 14);
		frame.getContentPane().add(lblEjAa);
		
		JLabel lblEntreY = new JLabel("Entre 8 y 22");
		lblEntreY.setForeground(Color.GRAY);
		lblEntreY.setBounds(213, 384, 65, 14);
		frame.getContentPane().add(lblEntreY);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(26, 458, 276, 2);
		frame.getContentPane().add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setOrientation(SwingConstants.VERTICAL);
		separator_1.setBounds(194, 460, 2, 50);
		frame.getContentPane().add(separator_1);

		MateriaText = new JTextField();
		MateriaText.setForeground(Color.CYAN);
		MateriaText.setBackground(Color.BLACK);
		MateriaText.setBounds(27, 405, 80, 20);
		MateriaText.setHorizontalAlignment(SwingConstants.CENTER);
		MateriaText.setFont(new Font("Tahoma", Font.PLAIN, 11));
		frame.getContentPane().add(MateriaText);
		MateriaText.setColumns(10);
		
		CodigoText = new JTextField();
		CodigoText.setForeground(Color.CYAN);
		CodigoText.setBackground(Color.BLACK);
		CodigoText.setBounds(124, 405, 50, 20);
		CodigoText.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(CodigoText);
		CodigoText.setColumns(10);
		
		HoraIniText = new JTextField();
		HoraIniText.setForeground(Color.CYAN);
		HoraIniText.setBackground(Color.BLACK);
		HoraIniText.setBounds(220, 405, 19, 20);
		HoraIniText.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(HoraIniText);
		HoraIniText.setColumns(10);

		HoraFinText = new JTextField();
		HoraFinText.setForeground(Color.CYAN);
		HoraFinText.setBackground(Color.BLACK);
		HoraFinText.setBounds(279, 406, 19, 20);
		HoraFinText.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(HoraFinText);
		HoraFinText.setColumns(10);
		
		removeMateriaText = new JTextField();
		removeMateriaText.setForeground(Color.CYAN);
		removeMateriaText.setBackground(Color.BLACK);
		removeMateriaText.setHorizontalAlignment(SwingConstants.CENTER);
		removeMateriaText.setBounds(27, 481, 50, 20);
		frame.getContentPane().add(removeMateriaText);
		removeMateriaText.setColumns(10);

		JButton btnMostrarArchivo = new JButton("Tomar Archivo");
		btnMostrarArchivo.setBackground(Color.GRAY);
		btnMostrarArchivo.setBounds(124, 95, 105, 20);
		frame.getContentPane().add(btnMostrarArchivo);
		
		JButton btnAgrMateria = new JButton("Agr. Materia");
		btnAgrMateria.setBackground(Color.GREEN);
		btnAgrMateria.setBounds(150, 432, 92, 20);
		btnAgrMateria.setForeground(Color.BLACK);
		frame.getContentPane().add(btnAgrMateria);

		JButton btnEliMateria = new JButton("Eli. Materia");
		btnEliMateria.setBackground(new Color(255, 255, 0));
		btnEliMateria.setBounds(87, 481, 92, 20);
		frame.getContentPane().add(btnEliMateria);
		
		//incializa el TextArchivo, y la posicion del archivo copia.
		ArchivoPosicionado = MateriasJson.CopiarArchivoJSON(Archivo.GetSelector());
		String MateriasText = MateriasJson.LeerArchivoJSON(Archivo.GetSelector());
		Archivo.SetJText(MateriasText);
		
		JButton btnEliTodo = new JButton("Eli. Todo");
		btnEliTodo.setBackground(Color.RED);
		btnEliTodo.setBounds(210, 481, 92, 20);
		frame.getContentPane().add(btnEliTodo);
		
		JButton btnAsignarAulas = new JButton("Asignar Aulas");
		btnAsignarAulas.setBackground(new Color(0, 51, 0));
		btnAsignarAulas.setBounds(541, 389, 130, 23);
		frame.getContentPane().add(btnAsignarAulas);
		
		JButton btnAnalisisProceso = new JButton("Analisis del Proceso");
		btnAnalisisProceso.setBackground(new Color(0, 51, 0));
		btnAnalisisProceso.setForeground(Color.BLACK);
		btnAnalisisProceso.setBounds(541, 478, 130, 23);
		frame.getContentPane().add(btnAnalisisProceso);
		
	//---------------------------------------------------------------------------
	//---------------------------- Eventos JBotton ------------------------------
	//---------------------------------------------------------------------------
		
		btnMostrarArchivo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {			
				ArchivoPosicionado = MateriasJson.CopiarArchivoJSON(Archivo.GetSelector());
				String MateriasText = MateriasJson.LeerArchivoJSON(Archivo.GetSelector());
				Archivo.SetJText(MateriasText);				
			}
		});
		
		btnAgrMateria.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String Mat = MateriaText.getText();
				String Cod = CodigoText.getText();
				String HoraInicio = HoraIniText.getText();
				String HoraFin = HoraFinText.getText();
				if(Checkeo.CodigoValido(ArchivoPosicionado, Cod)&&Checkeo.HorarioValido(HoraInicio, HoraFin)){
					int Ini = Integer.parseInt(HoraInicio);
					int Fin = Integer.parseInt(HoraFin);
					Materia M = new Materia(Mat,Cod,Ini,Fin); 
					ArchivoPosicionado.AgregarMateria(M);
					//actualizar JSON
					Archivo.ActualizarTextArchivo(ArchivoPosicionado, Archivo.GetSelector());
					//mostrar por pantalla
					Archivo.SetearTextArchivo(ArchivoPosicionado, MateriasJson, Archivo.GetSelector());
					Avisos.SetText("- Agregado Exitosamante.");
				}else{
					//Informamos en La Text-Notificacion
					String Notif = Avisos.TodasLasNotifAgregar(ArchivoPosicionado, Cod, HoraInicio, HoraFin);
					Avisos.SetText(Notif);
				}
			}
		});
		
		btnEliMateria.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Cod = removeMateriaText.getText();
				if(Checkeo.ExpresionCorrecta(Cod) && Checkeo.CodigoRepetido(ArchivoPosicionado, Cod)){
					Materia M = ArchivoPosicionado.BuscarMateriaPorCodigo(Cod);
					ArchivoPosicionado.EliminarMateria(M);
					//actualizar JSON
					Archivo.ActualizarTextArchivo(ArchivoPosicionado, Archivo.GetSelector());
					//mostrar por pantalla
					Archivo.SetearTextArchivo(ArchivoPosicionado, MateriasJson, Archivo.GetSelector());
					Avisos.SetText("- Eliminado Exitosamante.");
				}else{
					//Notificar por que no Elimino la Materia
					String Notif = Avisos.TodasLasNotifEliminar(ArchivoPosicionado, Cod);
					Avisos.SetText(Notif);
				}
			}
		});
		
		btnEliTodo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SubVentana.setVisible(true);
				ButtSiVentInterna.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						SubVentana.setVisible(false);
						ArchivoPosicionado = new MateriasJSON();
						//actualizar JSON
						Archivo.ActualizarTextArchivo(ArchivoPosicionado, Archivo.GetSelector());
						//mostrar por pantalla
						Archivo.SetearTextArchivo(ArchivoPosicionado, MateriasJson, Archivo.GetSelector());
						Avisos.SetText("- Eliminados Exitosamante.");
					}
				});
				ButtNoVentInterna.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						SubVentana.setVisible(false);
					}
				});
				
			}
		});

		btnAsignarAulas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {				
				Comisiones = new Aulas(); 
				ArrayList<Materia> CopiaMaterias = MateriasJson.CopiarArchivoArrayList(ArchivoPosicionado);
				Algoritmo.AlgoritmoGoloso(CopiaMaterias, Comisiones);
				Asignaciones.MostrarAsignaciones(Comisiones);
			}
		});
	
		btnAnalisisProceso.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String Notif = Avisos.TodasLasNotifProceso(Comisiones);
				Avisos.SetText(Notif);
			}
		});
		
	}

}
