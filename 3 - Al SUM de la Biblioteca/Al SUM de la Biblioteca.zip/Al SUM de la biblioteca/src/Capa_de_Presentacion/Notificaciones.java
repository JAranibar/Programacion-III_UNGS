package Capa_de_Presentacion;

import java.awt.Font;
import java.util.HashSet;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import Capa_de_Datos.Aulas;
import Capa_de_Datos.Materia;
import Capa_de_Datos.MateriasJSON;

public class Notificaciones {

	private JTextArea Notificaciones;
	
	public Notificaciones(JFrame frame) {
		Notificaciones = new JTextArea();
		Notificaciones.setFont(new Font("Monospaced", Font.PLAIN, 11));
		Notificaciones.setEditable(false);
		Notificaciones.setBounds(1, 1, 173, 50);
		
		JLabel lblNotificaciones = new JLabel("Notificaciones :");
		lblNotificaciones.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNotificaciones.setBounds(324, 365, 93, 14);
		frame.getContentPane().add(lblNotificaciones);

		JScrollPane scrollPane_1 = new JScrollPane(Notificaciones);
		scrollPane_1.setBounds(324, 390, 195, 111);
		frame.getContentPane().add(scrollPane_1);
	}
	
	public void SetText(String Contenido){
		this.Notificaciones.setText(Contenido);
	}
	
	public String TodasLasNotifAgregar(MateriasJSON Materias, String Codigo,String HoraIni,String HoraFin){
		String Resultado="";
		Resultado = Resultado + CodigoRepetido(Materias,Codigo);
		Resultado = Resultado + ExpresionCorrecta(Codigo);
		try {
			Integer.parseInt(HoraIni);
			Resultado = Resultado + "- Num. Ini. es un Numero.\n";
			Resultado = Resultado + "- Num. Ini. " + NumeroEnRango(HoraIni) + "\n";
		} catch (NumberFormatException nfe){
			Resultado = Resultado + "- Num. Ini. no es un Numero.\n";
		}
		try {
			Integer.parseInt(HoraFin);
			Resultado = Resultado + "- Num. Fin. es un Numero.\n";
			Resultado = Resultado + "- Num. Fin. " + NumeroEnRango(HoraFin) + "\n";
		} catch (NumberFormatException nfe){
			Resultado = Resultado + "- Num. Fin. no es un Numero.\n";
		}
		try {
			Integer.parseInt(HoraIni);
			Integer.parseInt(HoraFin);
			Resultado = Resultado + EsConsistente(HoraIni,HoraFin);	
		} catch (NumberFormatException nfe){
		}
		return Resultado;
	}

	public String TodasLasNotifEliminar(MateriasJSON Materias, String Codigo){
		String Resultado="";
		Resultado = Resultado + CodigoInexistenete(Materias,Codigo) + "\n";
		Resultado = Resultado + ExpresionCorrecta(Codigo) + "\n";
		return Resultado;
	}

	public String TodasLasNotifProceso(Aulas Comisiones){
		String Resultado="";
		Resultado = Resultado + "\n- Cantidad de Aulas: " + Comisiones.CantidadAulas()  + ".\n\n";
		Resultado = Resultado + "- Usabilidad:\n";
		Resultado = Resultado +  UsabilidadDeAulas(Comisiones);
		Resultado = Resultado + "\n- Disponibilidad:\n";
		Resultado = Resultado + DisponibilidadDeAulas(Comisiones);
		return Resultado;
	}

	private static String CodigoInexistenete(MateriasJSON Materias, String CodAEvaluar){
		for (int i=0; i<Materias.Tama�o(); i++){
			String CodigoIndice=Materias.dame(i).getCodigo();
			if(CodigoIndice.equals(CodAEvaluar)){
				return "";
			}
		}
		return "- Codigo Inexistente.\n";
	}
	
	private static String CodigoRepetido(MateriasJSON Materias, String CodAEvaluar){
		for (int i=0; i<Materias.Tama�o(); i++){
			String CodigoIndice=Materias.dame(i).getCodigo();
			if(CodigoIndice.equals(CodAEvaluar)){
				return "- Codigo Repetido.\n";
			}
		}
		return "";
	}
	
	private static String ExpresionCorrecta(String Codigo){
		// Quiere decir que acepta 2 Caracteres del alfabeto mayuscula
		// o miniscula luego un "-" y por ultimo 2 digitos.
		
		Pattern patter = Pattern.compile("([a-z]|[A-Z]){2}-[0-9]{2}");   
		Matcher masche = patter.matcher(Codigo);
		
		if (masche.matches()) {
	         return "";
	     } else {
	         return "- Expresion del Codigo\n  Incorrecta.\n";
	     }
	}
	
	private static String NumeroEnRango(String Numero){
		try {
			int Num = Integer.parseInt(Numero);
			if(Num>=8 && Num<=22){
				return "en Rango.";
			}
			return "fuera de Rango.";
		} catch (NumberFormatException nfe){
			return "";
		}
	}
	
	private static String EsConsistente(String Inicio, String Fin){
		try {
			int NumI = Integer.parseInt(Inicio);
			int NumF = Integer.parseInt(Fin);
			if(NumI<NumF){
				return "";
			}
			return "- Numeros Incoherentes.";
		} catch (NumberFormatException nfe){
			return "";
		}
	}
	
	private String UsabilidadDeAulas(Aulas Comisiones) {
		String Resul = "";
		for(int i=0; Comisiones.CantidadAulas()>i; i++){
			Resul = Resul + "     . Aula " + (i+1) + ":  ";
			HashSet<Materia> Relaciones = Comisiones.GetMaterias(i);
			Iterator<Materia> it = Relaciones.iterator();
			int Delta = 0;
			while(it.hasNext()){
				Materia M = it.next();
				int NumIni = M.getHoraInicio();
				int NumFin = M.getHoraFin();
				Delta = Delta + NumFin - NumIni;
			}
			int Porcentaje = (100*Delta)/14;
			Resul = Resul + Porcentaje + " %.\n";
		}
		return Resul;
	}
	
	private String DisponibilidadDeAulas(Aulas Comisiones){
		String Resultado = "";
		for(int i=0; Comisiones.CantidadAulas()>i; i++){
			Resultado = Resultado + "     - Aula " + (i+1) + ":\n";
			HashSet<Materia> Relaciones = Comisiones.GetMaterias(i);
			Iterator<Materia> it = Relaciones.iterator();
			MateriasJSON MateriasDelAula = new MateriasJSON();
			while(it.hasNext()){
				Materia M = it.next();
				MateriasDelAula.AgregarMateria(M);
			}
			MateriasDelAula.OrdenarPorHorario();
			for(int j=0;j<MateriasDelAula.Tama�o();j++){
				int INICIO = MateriasDelAula.dame(j).getHoraInicio();
				int FIN = MateriasDelAula.dame(j).getHoraFin();
				if(j==0 && INICIO!=8){
					Resultado = Resultado + "         .8 a " + INICIO +"\n";
				}
				if (j==MateriasDelAula.Tama�o()-1 && FIN!=22){
					Resultado = Resultado + "         ." + (FIN)+" a 22\n";
				}
				if(j!=MateriasDelAula.Tama�o()-1){
					int IniSig = MateriasDelAula.dame(j+1).getHoraInicio();
					if(FIN!=IniSig){
						Resultado = Resultado + "         ." + FIN + " a " + IniSig + "\n";
					}
				}
			}
		}
		return Resultado;
	}

}
