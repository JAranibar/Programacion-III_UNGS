package Capa_de_Presentacion;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import Capa_de_Datos.MateriasJSON;

public class ArchivoText {

	private JTextArea ArchivoText;
	@SuppressWarnings("rawtypes")
	private JComboBox SelectorArchivo;
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public ArchivoText(JFrame frame) {
		String[] step = {"Lunes","Martes","Miercoles","Jueves","Viernes","Sabado"};
		frame.getContentPane().setLayout(null);
		SelectorArchivo = new JComboBox(step);
		SelectorArchivo.setBounds(27, 95, 87, 20);
		frame.getContentPane().add(SelectorArchivo);
		
		ArchivoText = new JTextArea();
		ArchivoText.setBackground(Color.LIGHT_GRAY);
		ArchivoText.setEditable(false);
		ArchivoText.setBounds(37, 57, 173, 78);
		ArchivoText.setFont(new Font("Monospaced", Font.PLAIN, 11));
		frame.getContentPane().add(ArchivoText);
		
		JScrollPane scrollPane = new JScrollPane(ArchivoText);
		scrollPane.setBounds(21, 126, 303, 224);
		frame.getContentPane().add(scrollPane);
	}
	
	public void SetJText(String Contenido){
		ArchivoText.setText(Contenido);
	}
	
	public String GetSelector(){
		return (String) SelectorArchivo.getSelectedItem()+".JSON";
	}

	public void ActualizarTextArchivo(MateriasJSON ArchivoPosicionado, String archivo) {
		String jsonPretty = ArchivoPosicionado.generarJSONPretty();
		ArchivoPosicionado.generarJSON(jsonPretty, archivo);
	}
	
	public void SetearTextArchivo(MateriasJSON ArchivoPosicionado, MateriasJSON MateriasJson,String archivo) {
		ArchivoPosicionado = MateriasJson.CopiarArchivoJSON(archivo);
		String MateriasText = MateriasJson.LeerArchivoJSON(archivo);
		ArchivoText.setText(MateriasText);
	}
	
	
}
